package overridingproject;

public class Groceries extends Product{
	
void displayDetails() {
		
		System.out.println("Groceries: Pulses, Dairy,Vegetables");
		
	}
	
	void calculateShippingCost() {
		System.out.println("Groceries Shipping Cost: 650rs");
	}

}
