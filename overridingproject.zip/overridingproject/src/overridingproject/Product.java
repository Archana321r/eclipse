package overridingproject;

public class Product {

	void displayDetails() {
		System.out.println("Products List");
	}
	
	void calculateShippingCost() {
		System.out.println(" Shipping cost Starting From: 500rs");
	}
}


