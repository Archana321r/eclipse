package overridingproject;

public class Electronics extends Product {

	void  displayDetails() {
		
		System.out.println("Electronics: Laptops, TV,Computer");
		
	}
	
	void calculateShippingCost() {
		System.out.println("Electronics Shipping Cost: 1500rs");
	}
}
