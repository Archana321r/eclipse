package overridingproject;

public class Clothing extends Product{
	
void displayDetails() {
		
		System.out.println("Clothing:Jackets,Shirts,Uniform");
		
	}
	
	void calculateShippingCost() {
		System.out.println("Clothing Shipping Cost: 1000rs");
	}

}
