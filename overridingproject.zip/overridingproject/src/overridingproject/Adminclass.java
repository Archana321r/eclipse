package overridingproject;

public class Adminclass {
	
	public static void main(String[] args) {
		Product p1=new Product();
		System.out.println("---WELCOME TO ONLINE SHOPPING SYSTEM-----");
		p1.displayDetails();
		p1.calculateShippingCost();
		System.out.println("--------------");
		
		
		Product p2= new Electronics();{
			System.out.println("--- Electronic Page---");
			p2.calculateShippingCost();
			p2.displayDetails();
			System.out.println("Visit to the Next");
			System.out.println("------------------");
			
		}
		Product p3=new Clothing();{
			System.out.println("---Clothing Page----");
			p3.calculateShippingCost();
			p3.displayDetails();
			System.out.println("Visit to the Next");
			System.out.println("------------------");
		}
		
		Product p4= new Groceries();{
			System.out.println("---Groceries Page---");
			p4.calculateShippingCost();
			p4.displayDetails();
			System.out.println("----THE END-----");
			
		}

			
			
		
		 
		 
		}
	

		}
